@php($googleAvailable = app(\App\Services\GoogleSignInService::class)->isAvailable())
@once
@push('head')<link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@500&display=swap" rel="stylesheet">@endpush
@endonce
<div class="google-signin">
    @if($googleAvailable)<a href="{{ route('auth.google') }}" class="google-signin-button">@else<button type="button" class="google-signin-button" disabled aria-describedby="google-unavailable">@endif
        <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5Z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65Z"/><path fill="#FBBC05" d="M10.53 28.59a14.4 14.4 0 0 1 0-9.18l-7.98-6.19A23.9 23.9 0 0 0 0 24c0 3.87.93 7.53 2.56 10.78l7.97-6.19Z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.91-5.8l-7.73-6c-2.15 1.45-4.92 2.3-8.18 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48Z"/></svg>
        <span>Continue with Google</span>
    @if($googleAvailable)</a>@else</button><p id="google-unavailable" class="google-unavailable">Google sign-in is not available yet. You can continue with email.</p>@endif
    <div class="auth-divider"><span>or continue with email</span></div>
</div>
