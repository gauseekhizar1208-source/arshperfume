@extends('layouts.app')

@section('title', 'Order Placed | Arsh Perfume')

@section('content')
@php($waUrl = $order->whatsappOrderUrl())
<div class="container-x py-16">
    <div class="card mx-auto max-w-2xl space-y-6 p-8 text-center sm:p-12">
        <p class="text-xs uppercase tracking-[0.3em] text-gold">Almost done</p>
        <h1 class="section-title">Send your order on WhatsApp</h1>
        <p class="text-sm text-muted">Order number <span class="font-medium text-white">{{ $order->order_number }}</span></p>

        <p class="alert-info text-left">Your order has been saved. To confirm it, tap the button below &mdash; WhatsApp will open with your order details ready to send to us. We'll reply with delivery and payment details.</p>

        <dl class="grid gap-4 border-y border-line py-6 text-left text-sm sm:grid-cols-2">
            <div><dt class="label">Total</dt><dd class="text-gold">{{ money($order->grand_total) }}</dd></div>
            <div><dt class="label">How to pay</dt><dd>On WhatsApp with us</dd></div>
            <div class="sm:col-span-2"><dt class="label">Delivering to</dt><dd>{{ $order->shippingAddressOneLine() }}</dd></div>
        </dl>

        <div class="flex flex-col justify-center gap-3">
            <a href="{{ $waUrl }}" id="wa-send" target="_blank" rel="noopener"
               class="btn-gold flex w-full items-center justify-center gap-2 text-base">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M.057 24l1.687-6.163a11.867 11.867 0 01-1.587-5.945C.16 5.335 5.495 0 12.05 0a11.817 11.817 0 018.413 3.488 11.824 11.824 0 013.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 01-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884a9.82 9.82 0 001.516 5.256l-.999 3.648 3.472-.903zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
                Send order on WhatsApp
            </a>
            <div class="flex flex-col justify-center gap-3 sm:flex-row">
                <a href="{{ route('track-order') }}" class="btn-outline">Track your order</a>
                <a href="{{ route('shop') }}" class="btn-ghost">Continue shopping</a>
            </div>
        </div>
        <p class="text-xs text-muted">If WhatsApp doesn't open automatically, use the green button above.</p>
    </div>
</div>

<script>
    // Open WhatsApp automatically once, so the order reaches the shop right away.
    (function () {
        var url = @json($waUrl);
        try {
            if (!sessionStorage.getItem('wa-sent-{{ $order->order_number }}')) {
                sessionStorage.setItem('wa-sent-{{ $order->order_number }}', '1');
                window.location.href = url;
            }
        } catch (e) { /* sessionStorage blocked — the button still works */ }
    })();
</script>
@endsection
